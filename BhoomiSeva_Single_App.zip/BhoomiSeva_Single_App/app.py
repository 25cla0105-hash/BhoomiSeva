from flask import Flask, render_template, request, redirect, url_for, session, jsonify

app = Flask(__name__)
app.secret_key = "bhoomiseva-demo-key"

# Demo accounts
USERS = {
    "ramesh": {"name": "Ramesh", "role": "farmer", "password": "1234"},
    "lakshmi": {"name": "Lakshmi", "role": "farmer", "password": "1234"},
    "srikanth": {"name": "Srikanth", "role": "surveyor", "password": "1234"},
}

@app.route("/")
def home():
    return render_template("index.html", user=session.get("user"))

@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").lower().strip()
        password = request.form.get("password", "")
        user = USERS.get(username)

        if user and user["password"] == password:
            session["user"] = {
                "username": username,
                "name": user["name"],
                "role": user["role"]
            }
            return redirect(url_for("dashboard"))

        return render_template("login.html", error="Invalid username or password.")

    return render_template("login.html")

@app.route("/demo/<username>")
def demo_login(username):
    user = USERS.get(username.lower())
    if not user:
        return redirect(url_for("login"))

    session["user"] = {
        "username": username.lower(),
        "name": user["name"],
        "role": user["role"]
    }
    return redirect(url_for("dashboard"))

@app.route("/dashboard")
def dashboard():
    user = session.get("user")
    if not user:
        return redirect(url_for("login"))
    return render_template("dashboard.html", user=user)

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("home"))

@app.route("/feature/<feature>")
def feature(feature):
    user = session.get("user")
    if not user:
        return redirect(url_for("login"))

    features = {
        "land": ("My Land", "View land-owner, acreage, survey status and verified land information."),
        "map": ("Land Survey Map", "View the demo land boundary, survey points and disputed-area markers."),
        "weather": ("Weather & Rain", "Weather and rainfall information for the selected land area."),
        "soil": ("Soil Information", "Soil type, moisture, water availability and farming guidance."),
        "report": ("Report Survey Problem", "Report incorrect boundaries, disputed areas or survey issues."),
        "complaints": ("My Complaints & Requests", "Track submitted complaints and survey/re-survey requests."),
        "assigned": ("Assigned Surveys", "Surveyor work queue containing assigned land-survey requests."),
        "verify": ("Verify Land", "Review land details and verify the survey information."),
        "boundary": ("Boundary Survey", "Record boundary points and identify possible boundary differences."),
        "evidence": ("Evidence Upload", "Attach survey photographs and supporting evidence."),
        "reports": ("Survey Reports", "Prepare and view digital survey reports."),
    }

    title, description = features.get(feature, ("BhoomiSeva", "Feature page"))
    return render_template("feature.html", user=user, title=title, description=description, feature=feature)

@app.route("/api/report", methods=["POST"])
def api_report():
    user = session.get("user")
    if not user:
        return jsonify({"ok": False, "message": "Please login first."}), 401

    data = request.get_json(silent=True) or {}
    issue = data.get("issue", "Survey problem")
    return jsonify({
        "ok": True,
        "message": f"Report submitted successfully for {issue}.",
        "request_id": "BS-2026-0017"
    })

if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
