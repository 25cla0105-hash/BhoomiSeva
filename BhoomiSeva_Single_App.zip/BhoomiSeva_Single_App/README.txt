# BhoomiSeva - Single App

A Flask prototype combining Farmer and Surveyor into ONE application.

## Run on Windows

1. Open Command Prompt / PowerShell in this folder.
2. Create a virtual environment (optional but recommended):
   `python -m venv venv`
3. Activate:
   `venv\Scripts\activate`
4. Install:
   `pip install -r requirements.txt`
5. Start:
   `python app.py`
6. Open:
   `http://localhost:5000`

## Demo accounts

- Farmer: `ramesh` / `1234`
- Farmer: `lakshmi` / `1234`
- Surveyor: `srikanth` / `1234`

## What is included

- One landing page
- One login
- Role-based Farmer/Surveyor dashboards
- Farmer land, map, weather, soil, complaints and problem reporting
- Surveyor assigned surveys, verification, boundary, evidence and reports
- Demo API for survey-problem submission
- Responsive UI
